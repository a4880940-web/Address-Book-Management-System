#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include<ctype.h>
#include "contact.h"
#include "file.h"
//#include "populate.h"


int validatename(const char *name) 
{
    int len = strlen(name);

    // find minimum length
    if (len < 3) 
    {
        printf("\033[1;31mError: Name must contain at least 3 characters.\033[0m\n");
        return 0;
    }

    // only alphabets and spaces allowed
    for (int i = 0; i < len; i++) 
    {
        if (!isalpha((unsigned char)name[i]) && name[i] != ' ') 
        {
            printf("\033[1;31mError: Name must contain only alphabets and spaces (no numbers or symbols).\033[0m\n");
            return 0;
        }
    }

    return 1; // valid
}
int validatephone(const char *phone, AddressBook *addressBook) 
{
    //  must be exactly 10 digits
    if (strlen(phone) != 10) 
    {
        printf("\033[1;31mError: Phone number must contain exactly 10 digits.\033[0m\n");
        return 0;
    }

    //  first digit must be between 6 and 9
    if (phone[0] < '6' || phone[0] > '9') 
    {
        printf("\033[1;31mError: First digit must be between 6 and 9.\033[0m\n");
        return 0;
    }
    // only digits allowed
    for (int i = 0; phone[i] != '\0'; i++) 
    {
        if (!isdigit((unsigned char)phone[i])) 
        {
            printf("\033[1;31mError: Phone number must contain only digits (no alphabets or symbols).\033[0m\n");
            return 0;
        }
    }
    // phone number uniqueness check
    for (int i = 0; i < addressBook->contactCount; i++) {
        if (strcmp(addressBook->contacts[i].phone, phone) == 0) {
            printf("\033[1;31m Error: Phone number already exists.\033[0m\n");
            return 0;
        }
    }
    return 1; // valid
}
int validateemail(const char *email, AddressBook *addressBook)
{
    int atCount = 0, dotAfterAt = 0, atPosition = -1, dotPosition = -1;

    for (int i = 0; email[i] != '\0'; i++)
    {
        char ch = email[i];

        //  only lowercase letters and digits allowed
        if (!(islower((unsigned char)ch) || isdigit((unsigned char)ch) || ch == '@' || ch == '.')) {
            printf("\033[1;31mEmail must contain only lowercase letters and digits\033[0m\n");
            return 0;
        }

        // exactly one '@'
        if (ch == '@') {
            atCount++;
            atPosition = i;
        }

        // dot after '@'
        if (ch == '.') {
            dotPosition = i;
            if (atPosition != -1 && i > atPosition + 1) {
                dotAfterAt = 1;
            }
        }
    }

    // Check @ count
    if (atCount != 1) {
        printf("\033[1;31m Error:Email must contain exactly one '@' symbol.\033[0m\n");
        return 0;
    }

    // Check dot after @
    if (!dotAfterAt) {
        printf("\033[1;31m Error :Email must contain a '.' after '@' with at least one character in between.\033[0m\n");
        return 0;
    }

    // Rule 5: must end with ".com" exactly
    int len = strlen(email);
    if (len < 4 || strcmp(email + len - 4, ".com") != 0) {
        printf("\033[1;31m Error :Email must end with '.com'\033[0m\n");
        return 0;
    }

    // Ensure no extra characters after ".com"
    if (email[len] != '\0') {
        printf("\033[1;31m Error :No extra characters allowed after '.com'\033[0m\n");
        return 0;
    }

    // Rule 6: uniqueness check
    for (int i = 0; i < addressBook->contactCount; i++) {
        if (strcmp(addressBook->contacts[i].email, email) == 0) {
            printf("\033[1;31m Error :Email already exists.\033[0m\n");
            return 0;
        }
    }

    return 1; // valid
}
void sortContacts(AddressBook *addressBook, int sortCriteria)
{

    for (int i = 0; i < addressBook->contactCount - 1; i++) 
    {
        for (int j = i + 1; j < addressBook->contactCount; j++)
        {
            int cmp = 0;

            if (sortCriteria == 1) {
                cmp = strcmp(addressBook->contacts[i].name, addressBook->contacts[j].name);
            } else if (sortCriteria == 2) {
                cmp = strcmp(addressBook->contacts[i].phone, addressBook->contacts[j].phone);
            } else if (sortCriteria == 3) {
                cmp = strcmp(addressBook->contacts[i].email, addressBook->contacts[j].email);
            }

            if (cmp > 0) 
            {
                Contact temp = addressBook->contacts[i];
                addressBook->contacts[i] = addressBook->contacts[j];
                addressBook->contacts[j] = temp;
            }
        }
    }
}
void listContacts(AddressBook *addressBook,int sortCriteria) 
{
    if (addressBook->contactCount == 0) 
    {
        printf("\nThe Address Book is completely empty.\n");
        return;
    }

    // Sort if valid criteria
    if (sortCriteria >= 1 && sortCriteria <= 3)
    {
        sortContacts(addressBook, sortCriteria);
    }

    // Print table header
    printf("\n====================================================================================\n");
    printf("%-5s | %-25s | %-18s | %-30s\n", "S.No", "Name", "Phone Number", "Email ID");
    printf("====================================================================================\n");

    // Print each contact
    for (int i = 0; i < addressBook->contactCount; i++) {
        printf("%-5d | %-25.25s | %-18.18s | %-30.30s\n",
               (i + 1),
               addressBook->contacts[i].name,
               addressBook->contacts[i].phone,
               addressBook->contacts[i].email);
    }

    printf("====================================================================================\n");
    printf("Total Contacts: %d\n\n", addressBook->contactCount);
}

// Initialize address book at program start
void initialize(AddressBook *addressBook)
{
    addressBook->contactCount = 0; // reset count

    // Load contacts from file during initialization
    loadContactsFromFile(addressBook);

    printf("\033[0;32mAddress book initialized. %d contacts loaded.\033[0m\n",
           addressBook->contactCount);
}

// Save contacts and exit program
void saveAndExit(AddressBook *addressBook)
{
    saveContactsToFile(addressBook); // Save contacts to file
    printf("\033[0;32mContacts saved. Exiting program...\033[0m\n");
    exit(EXIT_SUCCESS); // Exit the program
}
void createContact(AddressBook *addressBook)
{
    // Check if address book is full
    if (addressBook->contactCount >= MAX_CONTACTS) {
        printf("Address book is full. Cannot add more contacts.\n");
        return;
    }

    Contact *newcontact = &addressBook->contacts[addressBook->contactCount]; // pointer to the new contact slot
    int attempts = 3;   // number of retries allowed for name input
    int valid = 0;      // flag to track if name validation passed

    // --- Name input with retries ---
    while (attempts > 0 && !valid) {
        printf("Enter name: ");
        scanf(" %[^\n]", newcontact->name);  // read full line including spaces into name field

        if (validatename(newcontact->name)) 
        {
            valid = 1; // mark as valid
        } 
        else 
        {
            attempts--; // reduce attempts if invalid
            if (attempts > 0) 
            {
                printf("\033[1;31m Error :Invalid name. Please try again (%d attempts left).\n", attempts);
            }
            else 
            {
                printf("\033[1;31m Error :Maximum attempts reached. Contact not added.\033[0m\n");
                return; // stop if all attempts used
            }
        }
    }
    // --- Phone input ---
    printf("Enter phone: ");
    scanf("%19s", newcontact->phone); // read phone number into phone field
    if (!validatephone(newcontact->phone, addressBook)) // validate phone rules + uniqueness
    {
        printf("\033[1;31m Error :Invalid phone number. Contact not added.\033[0m\n");
        return;
    }
    
    // --- Email input ---
    printf("Enter email: ");
    scanf("%49s", newcontact->email); // read email into email field
    if (!validateemail(newcontact->email, addressBook)) { // validate email rules + uniqueness
        printf("\033[1;31m Error :Invalid email. Contact not added.\033[0m\n");
        return;
    }

    // --- Add contact ---
    addressBook->contactCount++; // increment total contacts after successful validation
    printf("Contact added successfully.\n");
}
void searchContact(AddressBook *addressBook) 
{
    int choice;              // user's choice for search type (name/phone/email/exit)

    while (1) 
    {
        printf("\n--- SEARCH MENU ---\n");
        printf("1. Search by Name\n");
        printf("2. Search by Phone Number\n");
        printf("3. Search by Email ID\n");
        printf("4. Exit\n");
        printf("Enter choice: ");

        if (scanf("%d", &choice) != 1) 
        {
            printf("\033[1;31mError: Invalid choice.\033[0m\n"); // red error message
            return;
        }

        if (choice == 4)
        {
            return; // exit search menu
        }

        if (choice < 1 || choice > 4) 
        {
            printf("\033[1;31mError: Invalid choice.\033[0m\n");
            continue;
        }

        int found = 0;        // flag to track if any contact matched
        int resultCount = 0;  // counts how many contacts matched

        if (choice == 1) 
        {
            char name[50];    // buffer to store user input for name
            printf("Enter the name (partial allowed): ");
            scanf(" %[^\n]", name);

            for (int i = 0; i < addressBook->contactCount; i++) 
            {
                // case-insensitive partial match for name
                if (strcasestr(addressBook->contacts[i].name, name) != NULL) 
                {
                    resultCount++;
                    printf("\n%d. Contact Found:\n", resultCount);
                    printf("Name : %s\n", addressBook->contacts[i].name);
                    printf("Phone: %s\n", addressBook->contacts[i].phone);
                    printf("Email: %s\n", addressBook->contacts[i].email);
                    found = 1;
                }
            }
        }
        else if (choice == 2) 
        {
            char phone[20];   // buffer to store user input for phone
            printf("Enter the phone: ");
            scanf("%19s", phone);

            for (int i = 0; i < addressBook->contactCount; i++) {
                // exact match for phone number
                if (strcmp(addressBook->contacts[i].phone, phone) == 0) 
                {
                    resultCount++;
                    printf("\n%d. Contact Found:\n", resultCount);
                    printf("Name : %s\n", addressBook->contacts[i].name);
                    printf("Phone: %s\n", addressBook->contacts[i].phone);
                    printf("Email: %s\n", addressBook->contacts[i].email);
                    found = 1;
                }
            }
        } 
        else if (choice == 3) 
        {
            char email[50];   // buffer to store user input for email
            printf("Enter the email (partial allowed): ");
            scanf("%49s", email);

            for (int i = 0; i < addressBook->contactCount; i++) {
                // case-insensitive partial match for email
                if (strcasestr(addressBook->contacts[i].email, email) != NULL) 
                {
                    resultCount++;
                    printf("\n%d. Contact Found:\n", resultCount);
                    printf("Name : %s\n", addressBook->contacts[i].name);
                    printf("Phone: %s\n", addressBook->contacts[i].phone);
                    printf("Email: %s\n", addressBook->contacts[i].email);
                    found = 1;
                }
            }
        }

        if (!found) 
        {
            printf("\033[1;31mError: No matching contact found.\033[0m\n"); // red error
        } 
        else 
        {
            printf("\nTotal Matches: %d\n", resultCount);
        }
    }
}
void editContact(AddressBook *addressBook) 
{
    int choice;              // user's choice for search type
    int foundCount = 0;      // counts how many contacts matched the search
    int targetIndex = -1;    // stores the array index of the contact selected for editing
    int matches[50];         // holds indices of all matching contacts when duplicates exist
    char query[50];          // temporary buffer to store user input (name/phone/email)

    printf("\n--- SEARCH MENU ---\n");
    printf("1. Edit by Name\n");
    printf("2. Edit by Phone Number\n");
    printf("3. Edit by Email ID\n");
    printf("4. Exit\n");
    printf("Enter choice: ");

    if (scanf("%d", &choice) != 1) 
    {
        printf("\033[1;31mInvalid choice.\033[0m\n");
        return;
    }

    if (choice == 4) return; // exit search menu
    if (choice < 1 || choice > 4) 
    {
        printf("\033[1;31mInvalid choice.\033[0m\n");
        return;
    }

    // --- Search for matches ---
    if (choice == 1) 
    {
        printf("Enter the current name: ");
        scanf(" %[^\n]", query);
        for (int i = 0; i < addressBook->contactCount; i++) 
        {
            if (strcasestr(addressBook->contacts[i].name, query) != NULL) 
            {
                matches[foundCount++] = i;
                printf("%d. %s | %s | %s\n", foundCount,
                       addressBook->contacts[i].name,
                       addressBook->contacts[i].phone,
                       addressBook->contacts[i].email);
            }
        }
    } 
    else if (choice == 2) 
    {
        printf("Enter the current phone: ");
        scanf("%49s", query);
        for (int i = 0; i < addressBook->contactCount; i++) 
        {
            if (strcmp(addressBook->contacts[i].phone, query) == 0) 
            {
                matches[foundCount++] = i;
                printf("%d. %s | %s | %s\n", foundCount,
                       addressBook->contacts[i].name,
                       addressBook->contacts[i].phone,
                       addressBook->contacts[i].email);
            }
        }
    } 
    else if (choice == 3) 
    {
        printf("Enter the current email: ");
        scanf("%49s", query);
        for (int i = 0; i < addressBook->contactCount; i++) 
        {
            if (strcmp(addressBook->contacts[i].email, query) == 0)
            {
                matches[foundCount++] = i;
                printf("%d. %s | %s | %s\n", foundCount,
                       addressBook->contacts[i].name,
                       addressBook->contacts[i].phone,
                       addressBook->contacts[i].email);
            }
        }
    }
    if (foundCount == 0) 
    {
        printf("\033[1;31mContact not found.\033[0m\n");
        return;
    }
    if (foundCount > 1) 
    {
        printf("Multiple matches found. Enter the number to edit: ");
        int select;
        scanf("%d", &select);
        if (select < 1 || select > foundCount) 
        {
            printf("\033[1;31mInvalid selection.\033[0m\n");
            return;
        }
        targetIndex = matches[select - 1];
    } 
    else 
    {
        targetIndex = matches[0];
    }

    // --- Editing submenu ---
    int editChoice;
    while (1) 
    {
        printf("\n--- CURRENT CONTACT DETAILS ---\n");
        printf("Name  : %s\n", addressBook->contacts[targetIndex].name);
        printf("Phone : %s\n", addressBook->contacts[targetIndex].phone);
        printf("Email : %s\n", addressBook->contacts[targetIndex].email);

        printf("\nWhat would you like to edit?\n");
        printf("1. Edit Name\n");
        printf("2. Edit Phone Number\n");
        printf("3. Edit Email ID\n");
        printf("4. Exit (Save changes)\n");
        printf("5. Exit without saving\n");
        printf("Enter choice: ");
        scanf("%d", &editChoice);

        switch (editChoice) 
        {
            case 1: 
            {
                char newName[50];
                printf("Enter new name: ");
                scanf(" %[^\n]", newName);
                if (validatename(newName)) 
                {
                    strcpy(addressBook->contacts[targetIndex].name, newName);
                    printf("\033[0;32mName updated successfully!\033[0m\n");
                } 
                else 
                {
                    printf("\033[1;31mError: Invalid name.\033[0m\n");
                }
                break;
            }
            case 2: 
            {
                char newPhone[20];
                printf("Enter new phone number: ");
                scanf("%19s", newPhone);
                if (validatephone(newPhone, addressBook)) 
                {
                    strcpy(addressBook->contacts[targetIndex].phone, newPhone);
                    printf("\033[0;32mPhone updated successfully!\033[0m\n");
                } 
                else 
                {
                    printf("\033[1;31mError: Invalid phone.\033[0m\n");
                }
                break;
            }
            case 3: 
            {
                char newEmail[50];
                printf("Enter new email ID: ");
                scanf("%49s", newEmail);
                if (validateemail(newEmail, addressBook)) 
                {
                    strcpy(addressBook->contacts[targetIndex].email, newEmail);
                    printf("\033[0;32mEmail updated successfully!\033[0m\n");
                } 
                else 
                {
                    printf("\033[1;31mError: Invalid email.\033[0m\n");
                }
                break;
            }
            case 4:
                printf("\033[0;32mChanges saved.\033[0m\n");
                return; // exit function immediately
            case 5:
                printf("\033[1;33mExited without saving changes.\033[0m\n");
                return; // exit function immediately
            default:
                printf("\033[1;31mInvalid choice. Try again.\033[0m\n");
        }
    }
}

void deleteContact(AddressBook *addressBook) 
{
    int choice;              // user's choice for search type
    int foundCount = 0;      // number of matching contacts
    int matches[50];         // indices of matching contacts
    char query[50];          // buffer to hold user input

    printf("\n--- DELETE MENU ---\n");
    printf("1. Delete by Name\n");
    printf("2. Delete by Phone Number\n");
    printf("3. Delete by Email ID\n");
    printf("4. Exit\n");
    printf("Enter choice: ");

    if (scanf("%d", &choice) != 1) 
    {
        printf("\033[1;31mError: Invalid choice.\033[0m\n");
        return;
    }

    if (choice == 4) return; // exit delete menu
    if (choice < 1 || choice > 4) 
    {
        printf("\033[1;31mError: Invalid choice.\033[0m\n");
        return;
    }

    // --- Search for matches ---
    if (choice == 1) 
    {
        printf("Enter the name: ");
        scanf(" %[^\n]", query); // query holds name input
        for (int i = 0; i < addressBook->contactCount; i++) 
        {
            if (strcasestr(addressBook->contacts[i].name, query) != NULL) 
            {
                matches[foundCount++] = i;
                printf("%d. %s | %s | %s\n", foundCount,
                       addressBook->contacts[i].name,
                       addressBook->contacts[i].phone,
                       addressBook->contacts[i].email);
            }
        }
    } 
    else if (choice == 2) 
    {
        printf("Enter the phone: ");
        scanf("%49s", query); // query holds phone input
        for (int i = 0; i < addressBook->contactCount; i++) 
        {
            if (strcmp(addressBook->contacts[i].phone, query) == 0) 
            {
                matches[foundCount++] = i;
                printf("%d. %s | %s | %s\n", foundCount,
                       addressBook->contacts[i].name,
                       addressBook->contacts[i].phone,
                       addressBook->contacts[i].email);
            }
        }
    } 
    else if (choice == 3) 
    {
        printf("Enter the email: ");
        scanf("%49s", query); // query holds email input
        for (int i = 0; i < addressBook->contactCount; i++) 
        {
            if (strcmp(addressBook->contacts[i].email, query) == 0) 
            {
                matches[foundCount++] = i;
                printf("%d. %s | %s | %s\n", foundCount,
                       addressBook->contacts[i].name,
                       addressBook->contacts[i].phone,
                       addressBook->contacts[i].email);
            }
        }
    }

    if (foundCount == 0) 
    {
        printf("\033[1;31mError: Contact not found.\033[0m\n");
        return;
    }

    // --- Handle duplicates ---
    int targetIndex;
    if (foundCount > 1) 
    {
        printf("Multiple matches found. Enter the number to delete (or 0 to exit): ");
        int select;
        scanf("%d", &select);
        if (select == 0) 
        {
            printf("Delete cancelled.\n");
            return;
        }
        if (select < 1 || select > foundCount) 
        {
            printf("\033[1;31mError: Invalid selection.\033[0m\n");
            return;
        }
        targetIndex = matches[select - 1];
    } 
    else 
    {
        targetIndex = matches[0];
    }

    // --- Confirmation before deletion ---
    printf("\nYou are about to delete:\n");
    printf("Name  : %s\n", addressBook->contacts[targetIndex].name);
    printf("Phone : %s\n", addressBook->contacts[targetIndex].phone);
    printf("Email : %s\n", addressBook->contacts[targetIndex].email);

    printf("Are you sure? (Y/N): ");
    char confirm;
    scanf(" %c", &confirm);

    if (confirm == 'Y' || confirm == 'y') 
    {
        // Shift contacts left to overwrite deleted one
        for (int i = targetIndex; i < addressBook->contactCount - 1; i++) 
        {
            addressBook->contacts[i] = addressBook->contacts[i + 1];
        }
        addressBook->contactCount--; // reduce count
        printf("\033[0;32mContact deleted successfully!\033[0m\n");
    } 
    else 
    {
        printf("\033[1;33mDeletion cancelled.\033[0m\n");
    }
}

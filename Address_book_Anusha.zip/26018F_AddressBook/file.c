#include <stdio.h>
#include "file.h"

// Save contacts to file
void saveContactsToFile(AddressBook *addressBook)
{
    FILE *fp = fopen("contacts.txt", "w"); // overwrite file
    if (fp == NULL) {
        printf("\033[1;31mError: Could not open file for saving.\033[0m\n");
        return;
    }

    for (int i = 0; i < addressBook->contactCount; i++) {
        fprintf(fp, "\"%s\",%s,%s\n",
                addressBook->contacts[i].name,   // name in quotes
                addressBook->contacts[i].phone,  // phone digits
                addressBook->contacts[i].email); // email
    }

    fclose(fp);
    printf("\033[0;32mContacts saved successfully!\033[0m\n");
}

// Load contacts from file
void loadContactsFromFile(AddressBook *addressBook) 
{
    FILE *fp = fopen("contacts.txt", "r"); // read mode
    if (fp == NULL) {
        printf("\033[1;31mNo saved contacts found.\033[0m\n");
        return;
    }

    addressBook->contactCount = 0; // reset count

    // Read format: "Name",Phone,Email
    while (fscanf(fp, "\"%49[^\"]\",%19[^,],%49s",
                  addressBook->contacts[addressBook->contactCount].name,
                  addressBook->contacts[addressBook->contactCount].phone,
                  addressBook->contacts[addressBook->contactCount].email) == 3)
    {
        addressBook->contactCount++;
        if (addressBook->contactCount >= MAX_CONTACTS) {
            printf("\033[1;33mWarning: Maximum contacts reached while loading.\033[0m\n");
            break;
        }
    }

    fclose(fp);
    printf("\033[0;32mContacts loaded successfully!\033[0m\n");
}
